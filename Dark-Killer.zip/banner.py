from subprocess import Popen
import os
from colorama import Fore,Style
import time
import sys
def baner():
  os.system("clear")
  print(Fore.LIGHTRED_EX)
  print("""
  
██████╗  █████╗ ██████╗ ██╗  ██╗    ██╗  ██╗██╗██╗     ██╗     ███████╗██████╗ 
██╔══██╗██╔══██╗██╔══██╗██║ ██╔╝    ██║ ██╔╝██║██║     ██║     ██╔════╝██╔══██╗
██║  ██║███████║██████╔╝█████╔╝     █████╔╝ ██║██║     ██║     █████╗  ██████╔╝
██║  ██║██╔══██║██╔══██╗██╔═██╗     ██╔═██╗ ██║██║     ██║     ██╔══╝  ██╔══██╗
██████╔╝██║  ██║██║  ██║██║  ██╗    ██║  ██╗██║███████╗███████╗███████╗██║  ██║
╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝    ╚═╝  ╚═╝╚═╝╚══════╝╚══════╝╚══════╝╚═╝  ╚═╝

*******************************************************************************
***                                                                         ***
***                  Dark Killer Fake Page Maker Tool                       ***
***                       coded by : Sepehr                                 ***
***                                                                         ***
*******************************************************************************
  """)
  time.sleep(0.1)
def list1():
  baner()
  print(Fore.RED+" ["+Fore.LIGHTCYAN_EX+"卐"+Fore.RED+"] "+Fore.LIGHTCYAN_EX+"Choose one of the options below"+Fore.RED+" :)\n\n")
  time.sleep(0.1)
  print(Fore.RED+" ["+Fore.LIGHTWHITE_EX+"1"+Fore.RED+"] "+Fore.LIGHTYELLOW_EX+"Fake Pages ... !\n")
  time.sleep(0.1)
  print(Fore.RED+" ["+Fore.LIGHTWHITE_EX+"2"+Fore.RED+"] "+Fore.LIGHTBLUE_EX+"developers :)\n")
  time.sleep(0.1)
  print(Fore.RED+" ["+Fore.LIGHTWHITE_EX+"3"+Fore.RED+"] "+Fore.LIGHTRED_EX+"Exit . . . !\n")
def list2():
  baner()
  print(Fore.RED+" ["+Fore.LIGHTCYAN_EX+"卐"+Fore.RED+"] "+Fore.LIGHTCYAN_EX+"Choose one of the options below"+Fore.RED+" :)\n\n")
  time.sleep(0.1)
  print(Fore.RED+" ["+Fore.LIGHTWHITE_EX+"1"+Fore.RED+"] "+Fore.LIGHTGREEN_EX+"Instagram\n")
  time.sleep(0.1)
  print(Fore.RED+" ["+Fore.LIGHTWHITE_EX+"2"+Fore.RED+"] "+Fore.LIGHTBLUE_EX+"Coming Soon !\n")
  time.sleep(0.1)
  print(Fore.RED+" ["+Fore.LIGHTWHITE_EX+"3"+Fore.RED+"] "+Fore.LIGHTRED_EX+"Back To Menu\n")
def list3():
  baner()
  print(Fore.RED+" ["+Fore.LIGHTWHITE_EX+"卐"+Fore.RED+"] "+Fore.LIGHTCYAN_EX+"Developer"+Fore.LIGHTBLUE_EX+" : >> "+Style.BRIGHT+Fore.LIGHTYELLOW_EX+"Mr Sepehr\n"+Style.RESET_ALL)
  time.sleep(0.1)
  print(Fore.RED+" ["+Fore.LIGHTWHITE_EX+"卐"+Fore.RED+"] "+Fore.LIGHTCYAN_EX+"Channel"+Fore.LIGHTBLUE_EX+" : >> "+Style.BRIGHT+Fore.LIGHTRED_EX+"Cooming Soon ;)\n"+Style.RESET_ALL)
  time.sleep(0.1)
  print(Fore.RED+" ["+Fore.LIGHTWHITE_EX+"卐"+Fore.RED+"] "+Fore.LIGHTCYAN_EX+"Telegram Id"+Fore.LIGHTBLUE_EX+" : >> "+Style.BRIGHT+Fore.LIGHTMAGENTA_EX+"@x_darkpy_x\n"+Style.RESET_ALL)
  try:
    input(Fore.RED+" ["+Fore.LIGHTWHITE_EX+"卐"+Fore.RED+"] "+Fore.GREEN+"Back To Menu (Press Enter...)")
  except:
    print("")
    sys.exit()
def listi():
  baner()
  print(Fore.RED+" ["+Fore.LIGHTWHITE_EX+"1"+Fore.RED+"] "+Fore.LIGHTCYAN_EX+"Blue tick box template\n\n"+Fore.RED+" ["+Fore.LIGHTWHITE_EX+"2"+Fore.RED+"] "+Fore.LIGHTGREEN_EX+"Follower formatting\n\n"+Fore.RED+" ["+Fore.LIGHTWHITE_EX+"3"+Fore.RED+"] "+Fore.LIGHTRED_EX+"Back To Menu\n\n")