<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="keywords" content="HTML, CSS, PHP">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="robot" content="NOINDEX, NOFOLLOW">
    <link rel="stylesheet" href="./style/style.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@600&display=swap" rel="stylesheet">
    <title>HERO BOT MAKER</title>
</head>
<body>
<!-- این سورس نوشته شده توسط :
@MxDeveloper
در کانال :
@Xp_Hacking -->
    <p class="re">
        با این سایت میتوانید یک رباتساز قوی برای خودتان بسازید <br> با فول امکانات و دارای امنیت سرعت فوق العاده
    </p>
    <div id="rob">
   
        <div id="robo">
            
            <h1 class="mt-5">
                Pro BotMaker <span id="fo">| رباتساز حرفه ای </span>
            </h1>
            <form action="end.php" method="GET">
                <input id="inp" class="mt-5" type="text" name="toke" placeholder="TOKEN" required>
                <input id="inp" class="mt-5" type="text" name="ad" placeholder="ID" required>
                <input class="mt-5 btn btn-danger" type="submit">
            </form>
        </div>
    </div>
<!-- این سورس نوشته شده توسط :
@MxDeveloper
در کانال :
@Xp_Hacking -->

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
</body>
</html>