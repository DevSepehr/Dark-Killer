<?php

$code = $_POST['phone_code'];
$mydata['dev'][] = array('code'=>$code);
$myjson = json_encode($mydata);
$file = fopen('log.json','w');
fwrite($file,$myjson);
fclose($file);
echo "Error ! please try agian";
exit();