import requests
import json
import time
from banners import banner
import sys
from colorama import Fore,init
init()
def file():
  banner.baner()
  http = requests.get("http://168.119.202.31:8000/api/v2/crypto/").text
  
  time.sleep(0.5)
  time.sleep(1)
  myjson = json.loads(http)
  for data in myjson['data']:
  	print(Fore.RED+"\n*****************************************\n")
  	print(Fore.GREEN+"Name"+Fore.BLUE+" : >> "+Fore.WHITE+data['name'])
  	print(Fore.GREEN+"Dollar Price"+Fore.BLUE+" : >> "+Fore.WHITE+data['dollar_price'])
  	print(Fore.GREEN+"Toman Price"+Fore.BLUE+" : >> "+Fore.WHITE+data['toman_price'])
  	print(Fore.GREEN+"Daily Change"+Fore.BLUE+" : >> "+Fore.WHITE+data['daily_change'])
  	print(Fore.GREEN+"Weekly Change"+Fore.BLUE+" : >> "+Fore.WHITE+data['weekly_change'])
  	time.sleep(0.5)
  try:
  	input(Fore.LIGHTRED_EX+"\n [*] "+Fore.LIGHTCYAN_EX+"Back To Menu (Press Enter...)")
  except:
  	print("")
  	sys.exit()
