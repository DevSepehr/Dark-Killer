from colorama import Fore
import sys,time
from banners import banner
#/////////sepehr////////
def file():
  
  banner.baner()
  time.sleep(0.1)
  print(Fore.RED+" [ "+Fore.GREEN+" How to make a fake page ?! "+Fore.RED+" ]\n")
  time.sleep(0.1)
  print(Fore.CYAN+"                        [+]"+Fore.LIGHTRED_EX+" Turn on your hot spot \n")
  
  print(Fore.CYAN+"                        [+]"+Fore.LIGHTRED_EX+" install tor , install in termux : pkg install tor\n")
  print(Fore.CYAN+"                        [+]"+Fore.LIGHTRED_EX+" open a new session  and run tor :>> tor HTTPTunnelPort 8000 \n")
  
  time.sleep(0.5)
  print(Fore.RED+" [ "+Fore.GREEN+" How do I transfer target photos?  ?! "+Fore.RED+" ]\n")
  print(Fore.CYAN+"                        [+]"+Fore.LIGHTBLUE_EX+" Photos are saved in the (image) folder :)  \n")
  
  print(Fore.CYAN+"                        [+]"+Fore.LIGHTBLUE_EX+" With the cp command you can transfer the photo. Example : "+Fore.LIGHTBLUE_EX+'cp photo.jpg /sdcard  :))\n')
 
  try:
    input(Fore.RED+" [!] "+Fore.LIGHTCYAN_EX+"Back To menu (press Entet)...")
  except:
    print("")
    sys.exit()

