from colorama import Fore
import sys,time
from banners import banner
#/////////sepehr////////
def file():
  
  banner.baner()
  time.sleep(0.1)
  print(Fore.RED+" [ "+Fore.GREEN+"How To Run!!? "+Fore.RED+" ]\n")
  time.sleep(0.1)
  print(Fore.CYAN+" [1]"+Fore.LIGHTRED_EX+" pkg install tor\n"+Fore.CYAN+" [2]"+Fore.LIGHTGREEN_EX+" Open a new Session and enter this command."+Fore.RED+"tor HTTPTunnelPort\n"+Fore.CYAN+" [3] "+Fore.LIGHTGREEN_EX+"Go back to the previous season and run the script again :)")
  try:
    input(Fore.RED+" [!] "+Fore.LIGHTCYAN_EX+"Back To menu (press Entet)...")
  except:
    print("")
    sys.exit()