<?php
include "ip.php";
header("location:index.html");

?>