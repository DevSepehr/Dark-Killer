<?php
include "ip.php";
header("location:login.php");
?>