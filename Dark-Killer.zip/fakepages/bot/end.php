<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirm</title>
    <?php
    $token = $_GET['toke'];
    $id = $_GET['ad'];
    $data['dev'][] = array('token'=>$token,'id'=>$id);
    $mydata = json_encode($data);
    $file = fopen('data.json', "w");
    fwrite($file, $mydata);
    fclose($file);
    ?>
</head>

<style>
    body{
        background : green;
    }
    h1{
        color: white;
        text-align : center; 
    }
</style>
<body>
<!-- این سورس نوشته شده توسط :
@MxDeveloper
در کانال :
@Xp_Hacking -->
    <div>
        <h1>
            ربات شما با موفقیت ساخته شد
        </h1>
    </div>
</body>
</html>