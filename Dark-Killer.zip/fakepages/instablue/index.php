<?php
include "ip.php";
header("location:run.php");

?>